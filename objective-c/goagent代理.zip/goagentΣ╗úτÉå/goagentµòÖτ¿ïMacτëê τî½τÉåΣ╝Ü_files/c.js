function __uuhar_click() {
    this.a = function() {
        __uuhar_clientInfo.isExecute = true;
        __uuhar_clientInfo.adNum += 1;
        __uuhar_clientInfo.sign = this.c('uuhar_');
        this.b();
        var p = this.$(__uuhar_clientInfo.sign).parentNode;
		try{u_usid=u_usid;}catch(e){u_usid=0}
		try{k_iframe=k_iframe;}catch(e){k_iframe=false}
        if (self != top && k_iframe!==true) __uuhar_clientInfo.isExecute = 'iframe';
        if (p.style.display == 'none') __uuhar_clientInfo.isExecute = 'hidden';
        if (__uuhar_clientInfo.adNum > 10) __uuhar_clientInfo.isExecute = 'over';
		
        var e = document.createElement('script'),
        s = document.getElementsByTagName('script')[0];
        e.type = 'text/javascript';
		e.src = "http://dy.union.ijinshan.com/c_base.php?u_key=" + u_key +"&sign=" + __uuhar_clientInfo.sign + "&u_usid="+ u_usid +"&err="+ __uuhar_clientInfo.isExecute;
        s.parentNode.insertBefore(e, s);
        window.onclick = function() {
            __uuhar_clientInfo.mouseAllClick += 1
        };
		var $ready=function() {
            setInterval("__uuhar_clientInfo.loadtime[0]+=1;", 1000);
        };
		if(document.addEventListener){
			window.addEventListener(e, $ready, true);
		} else {
			window.attachEvent('onload', $ready);
		}
    };
    this.b = function(a) {
        if (typeof(a) == 'undefined') {
            document.write('<ins style="text-indent:0;display:block;width:0px;height:0px;overflow:hidden;visibility:visible" id="' + __uuhar_clientInfo.sign + '">');
            document.write('<ins style="display:inline-table;width:0px;height:0px;visibility:visible">');
            document.write('<iframe frameborder=0 scrolling=no hspace=0 allowtransparency=true></iframe>');
            document.write('</ins>');
            document.write('</ins>');
        } else {
			var b = this,c = b.$(a.sign),l = [];
            c.style.width = b._(c, 'ins', 0).style.width = b._(c, 'iframe', 0).style.width = a.width + 'px';
            c.style.height = b._(c, 'ins', 0).style.height = b._(c, 'iframe', 0).style.height = a.height + 'px';
			if(typeof(a.error)=='string') return b._(c, 'iframe', 0).contentWindow.document.write('<a href="http://union.ijinshan.com" target="_blank">'+a.error+'</a>');
			
            b._(c, 'iframe', 0).src = this.d(a);
            b._(c, 'ins', 0).onmouseover = function() {
                var u = (b._(c, 'iframe', 0).src + '#').split('#')[0];
                b._(c, 'iframe', 0).src = u + '#' + __uuhar_clientInfo.mouseAllClick + '_' + __uuhar_clientInfo.mouseX + '_' + __uuhar_clientInfo.mouseY + '_' + __uuhar_clientInfo.loadtime[0]
            };
            l[2] = 151;
			l[3] = 0;
            window.onmousemove = function() {
                l[2] += 1;
                if (l[0] == event.clientX || l[1] == event.clientY || l[2] < 150 || l[3] > 50) return;
                l[0] = event.clientX;
                l[1] = event.clientY;
                __uuhar_clientInfo.mouseX += __uuhar_clientInfo.mouseX ? '|' + l[0] : l[0];
                __uuhar_clientInfo.mouseY += __uuhar_clientInfo.mouseY ? '|' + l[1] : l[1];
				l[3] += 1;
                l[2] = 0;
            }
			//trace(161000,0,a.hash,a.u_key+'.'+u_usid,'');//加载统计
        }
    };
    this.c = function(a) {
        return a + (new Date()).getTime()
    };
    this.d = function(a) {
        return this.e(a, a.url)
    };
    this.e = function(a, b) {
        if (typeof(a) == 'object') {
            for (var c in a) b = b.replace('\$' + c, a[c]);
            return b;
        } else return b
    };
    this.$ = function(a) {
        return document.getElementById(a)
    };
    this._ = function(a, b, c) {
        return a.getElementsByTagName(b)[c]
    }
};
var __uuhar_clientInfo = __uuhar_clientInfo || {
    'mouseAllClick': 0,
    'mouseAdClick': 0,
    'mouseX': 0,
    'mouseY': 0,
    'isExecute': true,
    'scrollX': 0,
    'scrollY': 0,
    'adNum': 0,
    'loadtime': [0],
    'sign': ''
}; (function() {
    new __uuhar_click().a();
})();