# -*-coding:utf-8-*-

import os
import operator

#检查的文件路径 #可修改
DIR_PROJECT = "/Users/yucheng/Desktop/mobileBank/MBProject/MBProject/src/modules/accountManage"


#底下不需要修改
DIR_IGNORE = [".git",".svn"]

dictFilesH = {}
dictFilesM = {}

SHOW_PROPERTY_AND_RELEASE = False

# 遍历文件
def ListDirTempale(rootDir): 
    for lists in os.listdir(rootDir): 
        path = os.path.join(rootDir, lists) 
        print path
        if os.path.isdir(path): 
            ListDirTempale(path) 
def ListDir(rootDir): 
    for lists in os.listdir(rootDir): 
		if	lists in DIR_IGNORE:
			continue
		path = os.path.join(rootDir, lists)
		if	lists.endswith(".h"):
			dictFilesH[lists] = path
		if	lists.endswith(".m"):
			dictFilesM[lists] = path
		if os.path.isdir(path): 
			ListDir(path) 
class Param:
	def __init__(self,name,type,isRetain):
		self.name = name
		self.type = type
		self.isRetain = isRetain
		if type.startswith("UI") or type.startswith("MK"):
			self.isView = True;
		else:
			self.isView = False;

def parse_lines(lines):
#	print lines
	params = []
	deallocs = []
	tables = []
	readDeallocs = False
	for line in lines:
		
		s = line.strip()
		
		# dealloc
		if	"dealloc" in s and "void" in s:
			readDeallocs = True
		if	"super dealloc" in s:
			readDeallocs = False
		if	readDeallocs and s.startswith("[") and "release" in s:
			if SHOW_PROPERTY_AND_RELEASE:
				print s
			end = s.find(" ");
			newS = s[1:end]
			deallocs.append(newS)
			if newS[1:] not in tables:
				tables.append(newS[1:])
		
		# end dealloc
		if s.startswith("@property"):
			
			# check delegate
			if "id<" in s and ("retain" in s or "strong" in s or "copy" in s):
				print "[ERROR] delegate show assign -> " + s 
			
			isRetain = "retain" in s or "strong" in s or "copy" in s;
			
			if	isRetain :
				if SHOW_PROPERTY_AND_RELEASE:
					print s
			
			s = s.replace("*","")
			
			start = s.find(")")
			end = s.find(";")
			slist = s[start+1:end].split()
			name = slist[len(slist)-1]
			type = slist[len(slist)-2]
			
			p = Param(name,type,isRetain)
			
#			print "类型：%s，参数：%s，释放：%s,视图：%s \n" %(p.type,p.name,p.isRetain,p.isView)
			if p.isRetain and p.name not in params:
				params.append(p.name)
				if p.name not in tables:
					tables.append(p.name)
	
	if len(params) == 0:
		return
	
	if SHOW_PROPERTY_AND_RELEASE:
		print "tables  ->  " + " ".join(tables)
		print "params  ->  " + " ".join(params)
		print "release ->  " + " ".join(deallocs)
	
	print "-------------------------------------------------------------"
	s1 = "@property ->  %d" %(len(params))
	s2 = "release   ->  %d" %(len(deallocs))
	printCell(s1,s2)
	print "-------------------------------------------------------------"
	for s in tables:
		s_property = s
		s_release = "_" + s
		if s_property not in params:
			s_property = ""
		if s_release not in deallocs:
			s_release = ""
			
		printCell(s_property,s_release)
	print "-------------------------------------------------------------"
	
	
	
	print "\n"
	if	len(params) < len(deallocs):
		print "[ERROR] release 多了"
		code_list = deallocs
		code_num = {}
		for code_item in set(code_list):
			code_num[code_item]=code_list.count(code_item)
		#code_num是一个字典，当前是 {"a":3,"b",2} ,下面是对字典进行排序
		sorted_code = sorted( code_num.iteritems(), key=operator.itemgetter(1),reverse=True)
		
		print sorted_code
	if	len(params) > len(deallocs):
		print "[ERROR] release 少了"
	print "\n"
	
	if len(params) != len(deallocs):
		print "-(void) dealloc{"
		for s in params:
			print "    [_%s release];" %(s)
		print "    [super dealloc];"
		print "}\n\n"
	

def printCell(s1,s2):
	cellWidth = 27
	cellBlank = "                                        "
	print "|  " + s1 + cellBlank[0:cellWidth - len(s1)] + "-  " + s2 + cellBlank[0:cellWidth - len(s2)] + "-"
	
ListDir(DIR_PROJECT);

for	hFile in dictFilesH.keys():
#	if	hFile != "QGBaseViewController.h" :
#		continue
	pre = hFile[0:len(hFile)-2]
	mFile = pre + ".m"
	
	print "================= start with -> " + hFile + " & " + mFile + " "
	
	if	dictFilesM.has_key(mFile):
		hPath = dictFilesH[hFile]
		mPath = dictFilesM[mFile]
#		print hPath + " " + mPath 
		lines = []
		fh = open(hPath)        
		lines.extend(fh.readlines())
		fh = open(mPath)
		lines.extend(fh.readlines())
		
		parse_lines(lines)
	
	print "================= end \n\n\n"
		
			
	