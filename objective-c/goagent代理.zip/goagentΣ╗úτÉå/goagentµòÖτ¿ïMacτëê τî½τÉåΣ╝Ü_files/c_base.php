(function(){
	try{
	if (typeof(__uuhar_click)!='undefined')
	{
		var o = new __uuhar_click();
		o.b({
			'u_key': '335955',
			
			'hash': 'd9528fe0f5f0f2344c711488f48075acd04251b3',
			'sign': 'uuhar_1370423267310',
			'url': 'http://dy.union.ijinshan.com/c_code.php?u_key=335955&u_usid=0&width=468&height=60&hash=d9528fe0f5f0f2344c711488f48075acd04251b3',
			'width':'468',
			'height':'60'
		});
	}
	}catch(e){}
	})();